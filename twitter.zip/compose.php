<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Tweet composer</title>
<link href="twitter.css" type="text/css" rel="stylesheet" />
<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">
<link href="font-awesome/css/social-buttons.css" type=text/css rel=stylesheet>
</head>

<body>

<div class="column">

<!-- One big form for the whole page -->
<form class="compose">

<blockquote class="box twitter-tweet">
<figure><img src="stewart-48.png" width="48" height="48" alt="Picture of Stewart"/></figure>
<cite><a href="https://twitter.com/StewartCabbage">Stewart Cabbage LLC</a> <span class="id">@StewartCabbage</span></cite>
<p>@moron Sorry you hate cabbage. Not everyone has good taste.</p></blockquote>
<p class="count">59/140</p>

<p class="post">
<button class="btn btn-twitter" id="twitter" name="post" value="twitter"><i class="fa fa-twitter"></i> | Post to Twitter</button>
<button class="btn btn-twitter" name="cancel"><i class="fa fa-ban"></i> | Cancel</button>
</p>

<fieldset class="box">
<p><img src="right.png" width="17" height="16" alt=""/> @moron
  
<img src="left.png" width="17" height="16" alt=""/><img src="delete.png" width="17" height="16" alt=""/><img src="right.png" width="17" height="16" alt=""/> Sorry you hate cabbage.
  
<img src="left.png" width="17" height="16" alt=""/><img src="delete.png" width="17" height="16" alt=""/><img src="right.png" width="17" height="16" alt=""/> Not everyone has good taste.
</p>
</fieldset>

<fieldset class="box">
<p><label for="manual">Manual response: </label>
<input type="input" name="manual" id="manual">
</p>
<p class="addmanual"><input type="submit" name="addmanual" value="Add"></p>
<h2>Stock responses</h2>
<div class="items">
<p><img src="check.png" width="17" height="16" alt=""/> We'll send you a new one right away.</p>
<p><img src="check.png" width="17" height="16" alt=""/> Cabbage rules.</p>
<p><img src="check.png" width="17" height="16" alt=""/> Say hello to my little friend.</p>
<p><img src="check.png" width="17" height="16" alt=""/> That's really grating.</p>
<p><img src="check.png" width="17" height="16" alt=""/> What does a cabbage outlaw have? A price on his head.</p>
<p><img src="check.png" width="17" height="16" alt=""/> I was not born in a cabbage patch.</p>
<p><img src="check.png" width="17" height="16" alt=""/> I was born in a cabbage patch.</p>

<p><img src="check.png" width="17" height="16" alt=""/> LMFAO</p>
<p><img src="check.png" width="17" height="16" alt=""/> Green rules!</p>
<p><img src="check.png" width="17" height="16" alt=""/> I'm sorry about that.</p>
<p><img src="check.png" width="17" height="16" alt=""/> We're on it.</p>
<p><img src="check.png" width="17" height="16" alt=""/> Please call customer serice directly.</p>
<p><img src="check.png" width="17" height="16" alt=""/> Did you try plugging it in?</p>


</div>
</fieldset>
</form>
</div>



</body>
</html>