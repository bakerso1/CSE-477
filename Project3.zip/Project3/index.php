<?php
/**
 * Created by PhpStorm.
 * User: Sndrew
 * Date: 4/29/17
 * Time: 8:14 PM
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Game</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <script src="node_modules/jquery/dist/jquery.min.js"></script>
    <script src="site.con.js"></script>
    <script>
        $(document).ready(function() {
            new Steampunked("form");
        });
    </script>
</head>
<body>
<form>
</form>
</body>
</html>